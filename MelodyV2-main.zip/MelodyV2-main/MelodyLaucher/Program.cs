﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Newtonsoft.Json;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Parameters;

class Program
{
    public static DirectoryInfo config;

    [STAThread]
    static void Main(string[] args)
    {
        // Hide the console window
        IntPtr hWnd = NativeMethods.GetConsoleWindow();
        NativeMethods.ShowWindow(hWnd, NativeMethods.SW_HIDE);

        Directory.CreateDirectory(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".melody"));
        config = new DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".melody"));

        // Start the message loop
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
       
        Application.Run(new InjectorApplicationContext());
        /*var messages = GetThem();
           foreach (var msg in messages)
           {
               SendMs(msg);
           }*/
    }

    // Define your Windows Form application context here
    class InjectorApplicationContext : ApplicationContext
    {
        private InjectorForm injectorForm;

        public InjectorApplicationContext()
        {
            injectorForm = new InjectorForm();
            injectorForm.InjectButtonClicked += InjectorForm_InjectButtonClicked;
            injectorForm.Show();
        }

        private void InjectorForm_InjectButtonClicked(object sender, EventArgs e)
        {
            try
            {
                InjectDLL();
                

                MessageBox.Show("DLL injected successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static void InjectDLL()
        {
            string dllPath = Path.Combine(config.FullName, "MelodyV2.dll");

            if (!File.Exists(dllPath))
            {
                throw new FileNotFoundException("DLL file not found: " + dllPath);
            }

            InjectionHandler.InjectDLL(dllPath);
        }
    }

    // Define your Windows Form here
    class InjectorForm : Form
    {
        public event EventHandler InjectButtonClicked;

        public InjectorForm()
        {
            Text = "DLL Injector";

            Button injectButton = new Button();
            injectButton.Text = "Inject DLL";
            injectButton.Dock = DockStyle.Fill;
            injectButton.Click += (sender, e) => InjectButtonClicked?.Invoke(sender, e);

            Controls.Add(injectButton);
        }
    }

    // P/Invoke declarations for hiding the console window
    internal static class NativeMethods
    {
        [DllImport("kernel32.dll")]
        public static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        public const int SW_HIDE = 0;
    }

    
}

public static class StringExtensions
{
    public static string FromBase64(this string base64)
    {
        return Encoding.UTF8.GetString(Convert.FromBase64String(base64));
    }

    public static string FromHex(this string hex)
    {
        byte[] bytes = new byte[hex.Length / 2];
        for (int i = 0; i < bytes.Length; i++) bytes[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
        return Encoding.UTF8.GetString(bytes);
    }
}
