#pragma once

#include "ScreenControllerEvent.h"

class ContainerScreenControllerEvent : public ScreenControllerEvent {};