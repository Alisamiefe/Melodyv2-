#pragma once

class CaretMeasureData {
};