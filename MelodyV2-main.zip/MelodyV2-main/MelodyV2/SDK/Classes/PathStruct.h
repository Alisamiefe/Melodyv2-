#pragma once
#include "TextHolder.h"

class PathStruct {
private:
	char pad_0x0[0x18]; // 0x0
public:
	TextHolder filePath; // 0x18
};
