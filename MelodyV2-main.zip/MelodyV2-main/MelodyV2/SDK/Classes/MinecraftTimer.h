#pragma once

class MinecraftTimer {
public:
	float tps; // 0x0000
};