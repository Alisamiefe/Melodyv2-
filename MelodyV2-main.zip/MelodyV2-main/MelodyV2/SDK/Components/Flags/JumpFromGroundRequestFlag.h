#pragma once

struct JumpFromGroundRequestFlag {};