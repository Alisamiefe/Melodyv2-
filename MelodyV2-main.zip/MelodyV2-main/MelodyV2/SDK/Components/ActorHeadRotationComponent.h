#pragma once

#include "../../Utils/Math.h"


struct ActorHeadRotationComponent {
	float headRot;
	float oldHeadRot;
};