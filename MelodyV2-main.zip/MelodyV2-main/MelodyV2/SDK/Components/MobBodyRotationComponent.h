#pragma once

struct MobBodyRotationComponent
{
	float yBodyRot; //0x0000
	float yOldBodyRot; //0x0004
};