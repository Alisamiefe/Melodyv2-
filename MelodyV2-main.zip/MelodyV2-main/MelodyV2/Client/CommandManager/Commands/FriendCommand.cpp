#pragma once
#include <vector>
#include <string>
#include <algorithm>
#include "FriendCommand.h"

/*FriendCommand::FriendCommand(std::string commandName, std::string descr, std::vector<std::string> alias) : name(commandName), description(descr), aliases(alias) {
    std::transform(commandName.begin(), commandName.end(), commandName.begin(), ::tolower);
    this->aliases.push_back(commandName);
}

bool FriendCommand::execute(const std::vector<std::string>& args) {
    // Your implementation for execute goes here
    return true; // Change this return value based on your logic
}
*/