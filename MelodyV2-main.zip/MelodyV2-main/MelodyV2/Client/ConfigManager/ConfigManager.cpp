#include "ConfigManager.h"
#include "../../Client/Client.h"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iomanip>

void ConfigManager::saveConfig() {
    try { 
        std::string path = Utils::getClientPath() + "Configs\\";
        if (!std::filesystem::exists(path))
            std::filesystem::create_directory(path);

        if (client != nullptr && client->moduleMgr != nullptr) {
            client->moduleMgr->onSaveConfig(&currentConfigObj);
        }
        else {
            std::cerr << "Error: Client or module manager is nullptr\n";
        }

        std::string prefix = "A";
        if (client != nullptr && client->commandMgr != nullptr) {
            prefix[0] = client->commandMgr->prefix;
        }
        else {
            std::cerr << "Error: Client or command manager is nullptr\n";
        }
        currentConfigObj["prefix"] = prefix;

        std::string fullPath = path + currentConfig + ".json"; // Changed file extension to .json
        std::ofstream o(fullPath);
        if (o.is_open()) {
            o << std::setw(4) << currentConfigObj.dump(4) << std::endl; // Pretty print JSON
            o.flush();
            o.close();
        }
        else {
            std::cerr << "Error: Unable to open file for writing: " << fullPath << "\n";
        }
    }
    catch (const std::exception& e) {
        std::cerr << "Exception in saveConfig(): " << e.what() << "\n";
    }
}

void ConfigManager::loadConfig(std::string configName) {
    try {
        std::string path = Utils::getClientPath() + "Configs\\" + configName + ".json"; // Changed file extension to .json
        if (!std::filesystem::exists(path)) {
            std::cerr << "Error: Config file does not exist: " << path << "\n";
            return;
        }

        if (strcmp(configName.c_str(), currentConfig.c_str()) != 0) {
            saveConfig();
        }

        currentConfig = configName;
        std::ifstream confFile(path);
        if (confFile.is_open()) {
            currentConfigObj = json::parse(confFile);
            confFile.close();

            if (client != nullptr && client->moduleMgr != nullptr) {
                client->moduleMgr->onLoadConfig(&currentConfigObj);
            }
            else {
                std::cerr << "Error: Client or module manager is nullptr\n";
            }

            if (currentConfigObj.contains("prefix")) {
                std::string prefix = currentConfigObj["prefix"];
                if (!prefix.empty()) {
                    client->commandMgr->prefix = prefix.at(0);
                }
            }
        }
        else {
            std::cerr << "Error: Unable to open file for reading: " << path << "\n";
        }
    }
    catch (const std::exception& e) {
        std::cerr << "Exception in loadConfig(): " << e.what() << "\n";
    }
}
