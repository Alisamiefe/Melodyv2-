#include "AntiInvis.h"

AntiInvis::AntiInvis() : Module("AntiInvis", "Render invisible entity i think", Category::MISC) {
	//addSlider<int>("TPS", "NULL", ValueType::INT_T, &tps, 1, 150);
}
