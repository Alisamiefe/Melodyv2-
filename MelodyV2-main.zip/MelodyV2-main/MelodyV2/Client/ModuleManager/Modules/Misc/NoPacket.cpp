#include "NoPacket.h"

NoPacket::NoPacket() : Module("NoPacket", "Prevents packets from being sent to the server.", Category::MISC) {
}