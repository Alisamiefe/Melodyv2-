#pragma once
#include "../Module.h"

class NoPacket : public Module {
public:
	NoPacket();
};
