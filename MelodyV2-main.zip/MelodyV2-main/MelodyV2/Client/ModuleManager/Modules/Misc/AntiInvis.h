#pragma once
#include "../Module.h"

class AntiInvis : public Module {
private:
	//int tps = 20;
public:

	AntiInvis();
};
