/*#pragma once
#include "../Module.h"

class AutoArmor : public Module {
public:
	int swingSpeed = 6;

	AutoArmor();
	virtual void onNormalTick(Actor* actor) override;
};
*/