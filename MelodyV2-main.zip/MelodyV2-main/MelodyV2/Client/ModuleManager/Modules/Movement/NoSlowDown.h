#pragma once
#include "../Module.h"

class NoSlowDown : public Module {
public:

	NoSlowDown();
};
