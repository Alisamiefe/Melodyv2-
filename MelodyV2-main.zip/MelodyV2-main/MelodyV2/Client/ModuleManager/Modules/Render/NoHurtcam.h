#pragma once
#include "../Module.h"

class NoHurtcam : public Module {
public:
	NoHurtcam();
};