#include "NoHurtcam.h"

NoHurtcam::NoHurtcam() : Module("NoHurtcam", "Disable hurtcam animation", Category::RENDER) {
}