enum class mce::ImageUsage : unsigned char
{
    Unknown,
    sRGB,
    Data
}
