
class mce::RenderContextNull : public mce::RenderContextBase { /* Size=0x1b8 */
  /* 0x0000: fields for mce::RenderContextBase */
  
  RenderContextNull();
  ~RenderContextNull();
  void __autoclassinit2(uint64_t);
  void* __vecDelDtor(uint32_t);
};
