
enum PlayerRespawnState : unsigned char {
  SearchingForSpawn = 0x0000,
  ReadyToSpawn = 0x0001,
  ClientReadyToSpawn = 0x0002,
};
