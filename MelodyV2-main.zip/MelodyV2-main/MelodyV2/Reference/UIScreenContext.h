
class UIScreenContext { /* Size=0xc */
  /* 0x0000 */ const int32_t xm;
  /* 0x0004 */ const int32_t ym;
  /* 0x0008 */ const float a;
  
  UIScreenContext(const int32_t, const int32_t, const float);
};
