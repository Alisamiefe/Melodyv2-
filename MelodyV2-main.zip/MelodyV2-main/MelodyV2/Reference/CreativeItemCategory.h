enum class CreativeItemCategory : int
{
    CreativeItemCategory::All,
    CreativeItemCategory::Construction,
    CreativeItemCategory::Nature,
    CreativeItemCategory::Equipment,
    CreativeItemCategory::Items,
    CreativeItemCategory::ItemCommandOnly,
    CreativeItemCategory::Undefined,
    CreativeItemCategory::NUM_CATEGORIES
}